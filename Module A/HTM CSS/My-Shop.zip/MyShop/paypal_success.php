<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Untitled Document</title>
</head>

<body>

<h2> Welcome Guest!</h2>


<h3> You have succesfully paid for this product</h3>


<b>Please go to your account</b><br>
<a href="http://www.onlinetuting.com/myshop/customer/my_account.php">Go My Account</a>




</body>
</html>