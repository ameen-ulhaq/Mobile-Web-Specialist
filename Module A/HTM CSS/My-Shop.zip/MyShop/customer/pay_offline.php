<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Untitled Document</title>
</head>

<body bgcolor="#000000">

<table width="1000" border="2" cellspacing="2" cellpadding="2" bgcolor="#FFCCCC" align="center">
	
    <tr align="center">
    <td colspan="4"><h1>Pay using offline payment methods</h1></td>
    </tr>
  <tr>
    <th width="189" height="86" scope="row">Bank Account Details:</th>
    <td width="789"><p>Bank Name: UBL </p>
    <p>Account no: 23432423423423</p>
    <p>Branch Code: 2343</p>
    <p>Branch Name: University Road, Karachi</p></td>
  </tr>
  <tr>
    <th height="102" scope="row">Easypaisa, UBL Omni, MobiCash Details:</th>
    <td><p>N.I.C #: 3242343243243</p>
    <p>Mobile no: 234324324234</p>
    <p>Name: Abdul Wali Khan</p></td>
  </tr>
  <tr>
    <th height="190" scope="row">Western Union Details:</th>
    <td><p>Full Name: Abdul Wali Khan</p>
    <p>N.I.C # 23423432432</p>
    <p>Father Name: Gul Mohammad </p>
    <p>Country: Pakistan</p></td>
  </tr>
</table>

</body>
</html>