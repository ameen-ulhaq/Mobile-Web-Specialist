<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Untitled Document</title>
</head>

<body>

<h2>You have canceld the Payment!</h2>

<h3>Go to back to our shop</h3><br>

<a href="http://www.onlinetuting.com/myshop">Go to shop</a>


</body>
</html>