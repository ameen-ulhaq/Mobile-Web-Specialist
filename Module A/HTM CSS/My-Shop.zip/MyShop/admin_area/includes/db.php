<?php
//change this connect after uploading to online server

$con = mysqli_connect("localhost","root","","myshop");

?>